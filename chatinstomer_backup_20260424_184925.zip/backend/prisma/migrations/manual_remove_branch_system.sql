-- Remove Branch System
-- Drop the branch_mappings table
DROP TABLE IF EXISTS "branch_mappings";

-- Remove branchTag column from conversations table
ALTER TABLE "conversations" DROP COLUMN IF EXISTS "branchTag";
