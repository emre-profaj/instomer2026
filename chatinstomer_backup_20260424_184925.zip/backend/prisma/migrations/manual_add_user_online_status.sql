-- Add online/offline status tracking to users table
ALTER TABLE "users" ADD COLUMN IF NOT EXISTS "isOnline" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "users" ADD COLUMN IF NOT EXISTS "lastSeenAt" TIMESTAMP(3);

-- Reset all users to offline on migration (clean start)
UPDATE "users" SET "isOnline" = false;
