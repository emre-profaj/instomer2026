-- Quick Replies (Hazır Mesajlar) table
CREATE TABLE IF NOT EXISTS "quick_replies" (
    "id" TEXT NOT NULL,
    "workspaceId" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "content" TEXT NOT NULL,
    "shortcut" TEXT,
    "createdById" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "quick_replies_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "quick_replies_workspaceId_idx" ON "quick_replies"("workspaceId");

ALTER TABLE "quick_replies" ADD CONSTRAINT "quick_replies_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES "workspaces"("id") ON DELETE CASCADE ON UPDATE CASCADE;
