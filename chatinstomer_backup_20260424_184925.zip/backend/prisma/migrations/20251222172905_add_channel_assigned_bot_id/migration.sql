-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_conversations" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "status" TEXT NOT NULL DEFAULT 'OPEN',
    "contactId" TEXT NOT NULL,
    "workspaceId" TEXT NOT NULL,
    "facebookPageId" TEXT,
    "assignedToId" TEXT,
    "assignedBotId" TEXT,
    "whatsappPhoneNumberId" TEXT,
    "instagramBusinessId" TEXT,
    "emailChannelId" TEXT,
    "channel" TEXT NOT NULL DEFAULT 'UNKNOWN',
    "teamIds" TEXT NOT NULL DEFAULT '[]',
    "unreadCount" INTEGER NOT NULL DEFAULT 0,
    "lastMessageAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "conversations_assignedBotId_fkey" FOREIGN KEY ("assignedBotId") REFERENCES "ai_bots" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "conversations_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES "contacts" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "conversations_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES "workspaces" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "conversations_facebookPageId_fkey" FOREIGN KEY ("facebookPageId") REFERENCES "facebook_pages" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "conversations_assignedToId_fkey" FOREIGN KEY ("assignedToId") REFERENCES "users" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "conversations_whatsappPhoneNumberId_fkey" FOREIGN KEY ("whatsappPhoneNumberId") REFERENCES "whatsapp_phone_numbers" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "conversations_emailChannelId_fkey" FOREIGN KEY ("emailChannelId") REFERENCES "email_channels" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);
INSERT INTO "new_conversations" ("assignedToId", "channel", "contactId", "createdAt", "emailChannelId", "facebookPageId", "id", "instagramBusinessId", "lastMessageAt", "status", "teamIds", "unreadCount", "updatedAt", "whatsappPhoneNumberId", "workspaceId") SELECT "assignedToId", "channel", "contactId", "createdAt", "emailChannelId", "facebookPageId", "id", "instagramBusinessId", "lastMessageAt", "status", "teamIds", "unreadCount", "updatedAt", "whatsappPhoneNumberId", "workspaceId" FROM "conversations";
DROP TABLE "conversations";
ALTER TABLE "new_conversations" RENAME TO "conversations";
CREATE TABLE "new_email_channels" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "email" TEXT NOT NULL,
    "provider" TEXT NOT NULL DEFAULT 'GMAIL',
    "accessToken" TEXT NOT NULL,
    "refreshToken" TEXT NOT NULL,
    "expiryDate" BIGINT,
    "workspaceId" TEXT NOT NULL,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "assignedBotId" TEXT,
    "lastSyncAt" DATETIME,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "email_channels_assignedBotId_fkey" FOREIGN KEY ("assignedBotId") REFERENCES "ai_bots" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "email_channels_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES "workspaces" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "new_email_channels" ("accessToken", "createdAt", "email", "expiryDate", "id", "isActive", "lastSyncAt", "provider", "refreshToken", "updatedAt", "workspaceId") SELECT "accessToken", "createdAt", "email", "expiryDate", "id", "isActive", "lastSyncAt", "provider", "refreshToken", "updatedAt", "workspaceId" FROM "email_channels";
DROP TABLE "email_channels";
ALTER TABLE "new_email_channels" RENAME TO "email_channels";
CREATE UNIQUE INDEX "email_channels_email_key" ON "email_channels"("email");
CREATE TABLE "new_facebook_pages" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "pageId" TEXT NOT NULL,
    "pageName" TEXT NOT NULL,
    "pageAccessToken" TEXT NOT NULL,
    "workspaceId" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    "instagramBusinessId" TEXT,
    "instagramUsername" TEXT,
    "assignedBotId" TEXT,
    CONSTRAINT "facebook_pages_assignedBotId_fkey" FOREIGN KEY ("assignedBotId") REFERENCES "ai_bots" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "facebook_pages_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES "workspaces" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "new_facebook_pages" ("createdAt", "id", "instagramBusinessId", "instagramUsername", "pageAccessToken", "pageId", "pageName", "updatedAt", "workspaceId") SELECT "createdAt", "id", "instagramBusinessId", "instagramUsername", "pageAccessToken", "pageId", "pageName", "updatedAt", "workspaceId" FROM "facebook_pages";
DROP TABLE "facebook_pages";
ALTER TABLE "new_facebook_pages" RENAME TO "facebook_pages";
CREATE UNIQUE INDEX "facebook_pages_pageId_key" ON "facebook_pages"("pageId");
CREATE UNIQUE INDEX "facebook_pages_instagramBusinessId_key" ON "facebook_pages"("instagramBusinessId");
CREATE TABLE "new_web_widgets" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "workspaceId" TEXT NOT NULL,
    "title" TEXT NOT NULL DEFAULT 'Müşteri Destek',
    "subtitle" TEXT DEFAULT 'Size nasıl yardımcı olabiliriz?',
    "primaryColor" TEXT NOT NULL DEFAULT '#ef4444',
    "greetingMessage" TEXT DEFAULT 'Merhaba! Size nasıl yardımcı olabilirim?',
    "isActive" BOOLEAN NOT NULL DEFAULT false,
    "position" TEXT NOT NULL DEFAULT 'RIGHT',
    "width" INTEGER NOT NULL DEFAULT 350,
    "assignedBotId" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "web_widgets_assignedBotId_fkey" FOREIGN KEY ("assignedBotId") REFERENCES "ai_bots" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "web_widgets_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES "workspaces" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "new_web_widgets" ("createdAt", "greetingMessage", "id", "isActive", "position", "primaryColor", "subtitle", "title", "updatedAt", "width", "workspaceId") SELECT "createdAt", "greetingMessage", "id", "isActive", "position", "primaryColor", "subtitle", "title", "updatedAt", "width", "workspaceId" FROM "web_widgets";
DROP TABLE "web_widgets";
ALTER TABLE "new_web_widgets" RENAME TO "web_widgets";
CREATE UNIQUE INDEX "web_widgets_workspaceId_key" ON "web_widgets"("workspaceId");
CREATE TABLE "new_whatsapp_phone_numbers" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "phoneNumberId" TEXT NOT NULL,
    "wabaId" TEXT NOT NULL,
    "name" TEXT,
    "displayPhoneNumber" TEXT NOT NULL,
    "accessToken" TEXT NOT NULL,
    "workspaceId" TEXT NOT NULL,
    "assignedBotId" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "whatsapp_phone_numbers_assignedBotId_fkey" FOREIGN KEY ("assignedBotId") REFERENCES "ai_bots" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "whatsapp_phone_numbers_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES "workspaces" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "new_whatsapp_phone_numbers" ("accessToken", "createdAt", "displayPhoneNumber", "id", "name", "phoneNumberId", "updatedAt", "wabaId", "workspaceId") SELECT "accessToken", "createdAt", "displayPhoneNumber", "id", "name", "phoneNumberId", "updatedAt", "wabaId", "workspaceId" FROM "whatsapp_phone_numbers";
DROP TABLE "whatsapp_phone_numbers";
ALTER TABLE "new_whatsapp_phone_numbers" RENAME TO "whatsapp_phone_numbers";
CREATE UNIQUE INDEX "whatsapp_phone_numbers_phoneNumberId_key" ON "whatsapp_phone_numbers"("phoneNumberId");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
