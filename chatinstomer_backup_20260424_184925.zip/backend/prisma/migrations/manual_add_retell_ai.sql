-- Add Retell AI fields to workspaces
ALTER TABLE "workspaces" ADD COLUMN IF NOT EXISTS "retellApiKey" TEXT;
ALTER TABLE "workspaces" ADD COLUMN IF NOT EXISTS "retellAgentId" TEXT;
ALTER TABLE "workspaces" ADD COLUMN IF NOT EXISTS "retellFromNumber" TEXT;

-- Create RetellCall table
CREATE TABLE IF NOT EXISTS "retell_calls" (
    "id" TEXT NOT NULL DEFAULT gen_random_uuid(),
    "workspaceId" TEXT NOT NULL,
    "contactId" TEXT,
    "callId" TEXT NOT NULL,
    "agentId" TEXT,
    "fromNumber" TEXT NOT NULL,
    "toNumber" TEXT NOT NULL,
    "direction" TEXT NOT NULL DEFAULT 'outbound',
    "status" TEXT NOT NULL DEFAULT 'registered',
    "duration" INTEGER,
    "transcript" TEXT,
    "recordingUrl" TEXT,
    "summary" TEXT,
    "sentiment" TEXT,
    "callSuccessful" BOOLEAN,
    "endedReason" TEXT,
    "metadata" TEXT,
    "createdById" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "retell_calls_pkey" PRIMARY KEY ("id")
);

-- Create indexes
CREATE UNIQUE INDEX IF NOT EXISTS "retell_calls_callId_key" ON "retell_calls"("callId");
CREATE INDEX IF NOT EXISTS "retell_calls_workspaceId_idx" ON "retell_calls"("workspaceId");
CREATE INDEX IF NOT EXISTS "retell_calls_contactId_idx" ON "retell_calls"("contactId");
CREATE INDEX IF NOT EXISTS "retell_calls_callId_idx" ON "retell_calls"("callId");

-- Add foreign key
ALTER TABLE "retell_calls" ADD CONSTRAINT "retell_calls_workspaceId_fkey"
    FOREIGN KEY ("workspaceId") REFERENCES "workspaces"("id") ON DELETE CASCADE ON UPDATE CASCADE;
