-- Create funnel_stages table
CREATE TABLE IF NOT EXISTS "funnel_stages" (
    "id" TEXT NOT NULL,
    "funnelId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "color" TEXT NOT NULL DEFAULT '#6b7280',
    "order" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "funnel_stages_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "funnel_stages_funnelId_fkey" FOREIGN KEY ("funnelId") REFERENCES "funnels"("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- Add index
CREATE INDEX IF NOT EXISTS "funnel_stages_funnelId_idx" ON "funnel_stages"("funnelId");

-- Add funnelStageId column to conversations (IF NOT EXISTS for safety)
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'conversations' AND column_name = 'funnelStageId'
    ) THEN
        ALTER TABLE "conversations" ADD COLUMN "funnelStageId" TEXT;
    END IF;
END $$;
