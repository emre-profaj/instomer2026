-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_facebook_pages" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "pageId" TEXT NOT NULL,
    "pageName" TEXT NOT NULL,
    "pageAccessToken" TEXT NOT NULL,
    "workspaceId" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    "instagramBusinessId" TEXT,
    "instagramUsername" TEXT,
    "assignedBotId" TEXT,
    "instagramBotId" TEXT,
    CONSTRAINT "facebook_pages_assignedBotId_fkey" FOREIGN KEY ("assignedBotId") REFERENCES "ai_bots" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "facebook_pages_instagramBotId_fkey" FOREIGN KEY ("instagramBotId") REFERENCES "ai_bots" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "facebook_pages_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES "workspaces" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "new_facebook_pages" ("assignedBotId", "createdAt", "id", "instagramBusinessId", "instagramUsername", "pageAccessToken", "pageId", "pageName", "updatedAt", "workspaceId") SELECT "assignedBotId", "createdAt", "id", "instagramBusinessId", "instagramUsername", "pageAccessToken", "pageId", "pageName", "updatedAt", "workspaceId" FROM "facebook_pages";
DROP TABLE "facebook_pages";
ALTER TABLE "new_facebook_pages" RENAME TO "facebook_pages";
CREATE UNIQUE INDEX "facebook_pages_pageId_key" ON "facebook_pages"("pageId");
CREATE UNIQUE INDEX "facebook_pages_instagramBusinessId_key" ON "facebook_pages"("instagramBusinessId");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
