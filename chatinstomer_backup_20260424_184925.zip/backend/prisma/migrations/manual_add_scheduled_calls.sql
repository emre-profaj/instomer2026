-- Create scheduled_calls table for AI Call scheduling
CREATE TABLE IF NOT EXISTS `scheduled_calls` (
  `id` VARCHAR(191) NOT NULL,
  `workspaceId` VARCHAR(191) NOT NULL,
  `contactId` VARCHAR(191) NULL,
  `contactName` VARCHAR(191) NULL,
  `toNumber` VARCHAR(191) NOT NULL,
  `scheduledAt` DATETIME(3) NOT NULL,
  `status` VARCHAR(191) NOT NULL DEFAULT 'PENDING',
  `retellCallId` VARCHAR(191) NULL,
  `errorMessage` VARCHAR(191) NULL,
  `createdById` VARCHAR(191) NOT NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` DATETIME(3) NOT NULL,

  PRIMARY KEY (`id`),
  INDEX `scheduled_calls_workspaceId_idx`(`workspaceId`),
  INDEX `scheduled_calls_scheduledAt_idx`(`scheduledAt`),
  INDEX `scheduled_calls_status_idx`(`status`),
  CONSTRAINT `scheduled_calls_workspaceId_fkey` FOREIGN KEY (`workspaceId`) REFERENCES `workspaces`(`id`) ON DELETE CASCADE ON UPDATE CASCADE
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
