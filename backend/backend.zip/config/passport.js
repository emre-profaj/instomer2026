import passport from 'passport';
import { Strategy as JwtStrategy, ExtractJwt } from 'passport-jwt';
import { Strategy as FacebookStrategy } from 'passport-facebook';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// JWT Strategy
const jwtOptions = {
    jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
    secretOrKey: process.env.JWT_SECRET
};

passport.use(
    new JwtStrategy(jwtOptions, async (payload, done) => {
        try {
            const user = await prisma.user.findUnique({
                where: { id: payload.id }
            });

            if (user) {
                return done(null, user);
            }
            return done(null, false);
        } catch (error) {
            return done(error, false);
        }
    })
);

// Facebook Strategy
passport.use(
    new FacebookStrategy(
        {
            clientID: process.env.FACEBOOK_APP_ID,
            clientSecret: process.env.FACEBOOK_APP_SECRET,
            callbackURL: process.env.FACEBOOK_CALLBACK_URL,
            profileFields: ['id', 'emails', 'name', 'picture.type(large)']
        },
        async (accessToken, refreshToken, profile, done) => {
            try {
                // Check if user exists
                let user = await prisma.user.findUnique({
                    where: { facebookId: profile.id }
                });

                if (!user) {
                    // Create new user
                    user = await prisma.user.create({
                        data: {
                            facebookId: profile.id,
                            email: profile.emails?.[0]?.value || `${profile.id}@facebook.com`,
                            name: `${profile.name.givenName} ${profile.name.familyName}`,
                            avatar: profile.photos?.[0]?.value,
                            facebookAccessToken: accessToken
                        }
                    });
                } else {
                    // Update access token
                    user = await prisma.user.update({
                        where: { id: user.id },
                        data: { facebookAccessToken: accessToken }
                    });
                }

                return done(null, user);
            } catch (error) {
                return done(error, false);
            }
        }
    )
);

export default passport;
