import jwt from 'jsonwebtoken';
import passport from 'passport';

export const authenticateJWT = (req, res, next) => {
    passport.authenticate('jwt', { session: false }, (err, user, info) => {
        if (err) {
            return next(err);
        }

        if (!user) {
            return res.status(401).json({ error: 'Unauthorized' });
        }

        req.user = user;
        next();
    })(req, res, next);
};

export const requireRole = (...roles) => {
    return (req, res, next) => {
        if (!req.user) {
            return res.status(401).json({ error: 'Unauthorized' });
        }

        if (!roles.includes(req.user.role)) {
            return res.status(403).json({ error: 'Forbidden: Insufficient permissions' });
        }

        next();
    };
};

export const requireWorkspaceAccess = async (req, res, next) => {
    try {
        const workspaceId = req.params.workspaceId || req.body.workspaceId;

        if (!workspaceId) {
            return res.status(400).json({ error: 'Workspace ID is required' });
        }

        const { PrismaClient } = await import('@prisma/client');
        const prisma = new PrismaClient();

        const member = await prisma.workspaceMember.findUnique({
            where: {
                userId_workspaceId: {
                    userId: req.user.id,
                    workspaceId: workspaceId
                }
            }
        });

        await prisma.$disconnect();

        if (!member) {
            return res.status(403).json({ error: 'Access denied to this workspace' });
        }

        req.workspaceMember = member;
        next();
    } catch (error) {
        console.error('Workspace access check error:', error);
        return res.status(500).json({ error: 'Internal server error' });
    }
};

export const generateToken = (user) => {
    return jwt.sign(
        { id: user.id, email: user.email, role: user.role },
        process.env.JWT_SECRET,
        { expiresIn: process.env.JWT_EXPIRE || '7d' }
    );
};
