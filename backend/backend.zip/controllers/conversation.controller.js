import { validationResult } from 'express-validator';
import { PrismaClient } from '@prisma/client';
import axios from 'axios';

const prisma = new PrismaClient();
const GRAPH_API_VERSION = process.env.FACEBOOK_GRAPH_API_VERSION || 'v18.0';

export const getConversations = async (req, res) => {
    try {
        const { workspaceId } = req.params;
        const { status, assignedToId, page = 1, limit = 20 } = req.query;

        const where = {
            workspaceId,
            ...(status && { status }),
            ...(assignedToId && { assignedToId })
        };

        const conversations = await prisma.conversation.findMany({
            where,
            include: {
                contact: {
                    select: {
                        id: true,
                        name: true,
                        avatar: true,
                        email: true
                    }
                },
                assignedTo: {
                    select: {
                        id: true,
                        name: true,
                        avatar: true
                    }
                },
                facebookPage: {
                    select: {
                        id: true,
                        pageName: true
                    }
                },
                messages: {
                    orderBy: { createdAt: 'desc' },
                    take: 1,
                    select: {
                        id: true,
                        content: true,
                        createdAt: true,
                        isFromContact: true
                    }
                },
                _count: {
                    select: {
                        messages: true
                    }
                }
            },
            orderBy: { lastMessageAt: 'desc' },
            skip: (parseInt(page) - 1) * parseInt(limit),
            take: parseInt(limit)
        });

        const total = await prisma.conversation.count({ where });

        res.json({
            conversations,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total,
                totalPages: Math.ceil(total / parseInt(limit))
            }
        });
    } catch (error) {
        console.error('Get conversations error:', error);
        res.status(500).json({ error: 'Failed to fetch conversations' });
    }
};

export const getConversation = async (req, res) => {
    try {
        const { conversationId } = req.params;

        const conversation = await prisma.conversation.findUnique({
            where: { id: conversationId },
            include: {
                contact: true,
                assignedTo: {
                    select: {
                        id: true,
                        name: true,
                        avatar: true,
                        email: true
                    }
                },
                facebookPage: true,
                messages: {
                    orderBy: { createdAt: 'asc' },
                    include: {
                        sender: {
                            select: {
                                id: true,
                                name: true,
                                avatar: true
                            }
                        }
                    }
                }
            }
        });

        if (!conversation) {
            return res.status(404).json({ error: 'Conversation not found' });
        }

        res.json({ conversation });
    } catch (error) {
        console.error('Get conversation error:', error);
        res.status(500).json({ error: 'Failed to fetch conversation' });
    }
};

export const sendMessage = async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }

        const { conversationId } = req.params;
        const { content } = req.body;

        // Get conversation with Facebook page info
        const conversation = await prisma.conversation.findUnique({
            where: { id: conversationId },
            include: {
                contact: true,
                facebookPage: true
            }
        });

        if (!conversation) {
            return res.status(404).json({ error: 'Conversation not found' });
        }

        // Create message in database
        const message = await prisma.message.create({
            data: {
                content,
                conversationId,
                senderId: req.user.id,
                isFromContact: false,
                messageType: 'TEXT'
            },
            include: {
                sender: {
                    select: {
                        id: true,
                        name: true,
                        avatar: true
                    }
                }
            }
        });

        // Send message via Facebook API
        if (conversation.facebookPage && conversation.contact.facebookId) {
            try {
                await axios.post(
                    `https://graph.facebook.com/${GRAPH_API_VERSION}/me/messages`,
                    {
                        recipient: { id: conversation.contact.facebookId },
                        message: { text: content }
                    },
                    {
                        params: {
                            access_token: conversation.facebookPage.pageAccessToken
                        }
                    }
                );
            } catch (error) {
                console.error('Facebook send message error:', error.response?.data);
                // Don't fail the request, message is saved in DB
            }
        }

        // Update conversation last message time
        await prisma.conversation.update({
            where: { id: conversationId },
            data: { lastMessageAt: new Date() }
        });

        res.status(201).json({ message });
    } catch (error) {
        console.error('Send message error:', error);
        res.status(500).json({ error: 'Failed to send message' });
    }
};

export const assignConversation = async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }

        const { conversationId, workspaceId } = req.params;
        const { assignedToId } = req.body;

        // Verify the assignee is a member of the workspace
        const member = await prisma.workspaceMember.findUnique({
            where: {
                userId_workspaceId: {
                    userId: assignedToId,
                    workspaceId
                }
            }
        });

        if (!member) {
            return res.status(400).json({ error: 'User is not a member of this workspace' });
        }

        const conversation = await prisma.conversation.update({
            where: { id: conversationId },
            data: { assignedToId },
            include: {
                assignedTo: {
                    select: {
                        id: true,
                        name: true,
                        avatar: true
                    }
                }
            }
        });

        res.json({ conversation });
    } catch (error) {
        console.error('Assign conversation error:', error);
        res.status(500).json({ error: 'Failed to assign conversation' });
    }
};

export const updateConversationStatus = async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }

        const { conversationId } = req.params;
        const { status } = req.body;

        const conversation = await prisma.conversation.update({
            where: { id: conversationId },
            data: { status }
        });

        res.json({ conversation });
    } catch (error) {
        console.error('Update conversation status error:', error);
        res.status(500).json({ error: 'Failed to update conversation status' });
    }
};
