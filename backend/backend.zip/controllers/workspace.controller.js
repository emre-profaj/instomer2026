import { validationResult } from 'express-validator';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export const createWorkspace = async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }

        const { name, slug, description } = req.body;

        // Check if slug is already taken
        const existingWorkspace = await prisma.workspace.findUnique({
            where: { slug }
        });

        if (existingWorkspace) {
            return res.status(400).json({ error: 'Workspace slug already exists' });
        }

        // Create workspace and add creator as owner
        const workspace = await prisma.workspace.create({
            data: {
                name,
                slug,
                description,
                members: {
                    create: {
                        userId: req.user.id,
                        role: 'OWNER'
                    }
                }
            },
            include: {
                members: {
                    include: {
                        user: {
                            select: {
                                id: true,
                                name: true,
                                email: true,
                                avatar: true
                            }
                        }
                    }
                }
            }
        });

        res.status(201).json({ workspace });
    } catch (error) {
        console.error('Create workspace error:', error);
        res.status(500).json({ error: 'Failed to create workspace' });
    }
};

export const getWorkspaces = async (req, res) => {
    try {
        const workspaces = await prisma.workspace.findMany({
            where: {
                members: {
                    some: {
                        userId: req.user.id
                    }
                }
            },
            include: {
                members: {
                    where: {
                        userId: req.user.id
                    },
                    select: {
                        role: true
                    }
                },
                _count: {
                    select: {
                        members: true,
                        conversations: true
                    }
                }
            }
        });

        res.json({ workspaces });
    } catch (error) {
        console.error('Get workspaces error:', error);
        res.status(500).json({ error: 'Failed to fetch workspaces' });
    }
};

export const getWorkspace = async (req, res) => {
    try {
        const { workspaceId } = req.params;

        const workspace = await prisma.workspace.findUnique({
            where: { id: workspaceId },
            include: {
                members: {
                    include: {
                        user: {
                            select: {
                                id: true,
                                name: true,
                                email: true,
                                avatar: true
                            }
                        }
                    }
                },
                facebookPages: true,
                _count: {
                    select: {
                        conversations: true
                    }
                }
            }
        });

        if (!workspace) {
            return res.status(404).json({ error: 'Workspace not found' });
        }

        res.json({ workspace });
    } catch (error) {
        console.error('Get workspace error:', error);
        res.status(500).json({ error: 'Failed to fetch workspace' });
    }
};

export const getWorkspaceMembers = async (req, res) => {
    try {
        const { workspaceId } = req.params;

        const members = await prisma.workspaceMember.findMany({
            where: { workspaceId },
            include: {
                user: {
                    select: {
                        id: true,
                        name: true,
                        email: true,
                        avatar: true
                    }
                }
            }
        });

        res.json({ members });
    } catch (error) {
        console.error('Get workspace members error:', error);
        res.status(500).json({ error: 'Failed to fetch members' });
    }
};

export const addMember = async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }

        const { workspaceId } = req.params;
        const { email, role } = req.body;

        // Check if requester has permission (must be OWNER or ADMIN)
        if (!['OWNER', 'ADMIN'].includes(req.workspaceMember.role)) {
            return res.status(403).json({ error: 'Insufficient permissions' });
        }

        // Find user by email
        const user = await prisma.user.findUnique({
            where: { email }
        });

        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        // Check if already a member
        const existingMember = await prisma.workspaceMember.findUnique({
            where: {
                userId_workspaceId: {
                    userId: user.id,
                    workspaceId
                }
            }
        });

        if (existingMember) {
            return res.status(400).json({ error: 'User is already a member' });
        }

        // Add member
        const member = await prisma.workspaceMember.create({
            data: {
                userId: user.id,
                workspaceId,
                role
            },
            include: {
                user: {
                    select: {
                        id: true,
                        name: true,
                        email: true,
                        avatar: true
                    }
                }
            }
        });

        res.status(201).json({ member });
    } catch (error) {
        console.error('Add member error:', error);
        res.status(500).json({ error: 'Failed to add member' });
    }
};

export const updateMemberRole = async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }

        const { workspaceId, userId } = req.params;
        const { role } = req.body;

        // Check if requester has permission (must be OWNER or ADMIN)
        if (!['OWNER', 'ADMIN'].includes(req.workspaceMember.role)) {
            return res.status(403).json({ error: 'Insufficient permissions' });
        }

        const member = await prisma.workspaceMember.update({
            where: {
                userId_workspaceId: {
                    userId,
                    workspaceId
                }
            },
            data: { role },
            include: {
                user: {
                    select: {
                        id: true,
                        name: true,
                        email: true,
                        avatar: true
                    }
                }
            }
        });

        res.json({ member });
    } catch (error) {
        console.error('Update member role error:', error);
        res.status(500).json({ error: 'Failed to update member role' });
    }
};

export const removeMember = async (req, res) => {
    try {
        const { workspaceId, userId } = req.params;

        // Check if requester has permission (must be OWNER or ADMIN)
        if (!['OWNER', 'ADMIN'].includes(req.workspaceMember.role)) {
            return res.status(403).json({ error: 'Insufficient permissions' });
        }

        // Cannot remove yourself
        if (userId === req.user.id) {
            return res.status(400).json({ error: 'Cannot remove yourself' });
        }

        await prisma.workspaceMember.delete({
            where: {
                userId_workspaceId: {
                    userId,
                    workspaceId
                }
            }
        });

        res.json({ message: 'Member removed successfully' });
    } catch (error) {
        console.error('Remove member error:', error);
        res.status(500).json({ error: 'Failed to remove member' });
    }
};
