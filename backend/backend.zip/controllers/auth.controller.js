import bcrypt from 'bcryptjs';
import { validationResult } from 'express-validator';
import { PrismaClient } from '@prisma/client';
import { generateToken } from '../middleware/auth.middleware.js';

const prisma = new PrismaClient();

// Helper function to create slug from name
const createSlug = (name) => {
    return name
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-+|-+$/g, '');
};

export const register = async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }

        const { email, password, name } = req.body;

        // Check if user exists
        const existingUser = await prisma.user.findUnique({
            where: { email }
        });

        if (existingUser) {
            return res.status(400).json({ error: 'User already exists' });
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Create user with automatic workspace
        const user = await prisma.user.create({
            data: {
                email,
                password: hashedPassword,
                name,
                workspaceMembers: {
                    create: {
                        role: 'OWNER',
                        workspace: {
                            create: {
                                name: `${name}'s Workspace`,
                                slug: `${createSlug(name)}-${Date.now()}`,
                                description: 'My personal workspace'
                            }
                        }
                    }
                }
            },
            include: {
                workspaceMembers: {
                    include: {
                        workspace: true
                    }
                }
            }
        });

        // Generate token
        const token = generateToken(user);

        // Get the created workspace
        const workspace = user.workspaceMembers[0]?.workspace;

        res.status(201).json({
            user: {
                id: user.id,
                email: user.email,
                name: user.name,
                role: user.role
            },
            workspace: workspace ? {
                id: workspace.id,
                name: workspace.name,
                slug: workspace.slug
            } : null,
            token
        });
    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({ error: 'Registration failed' });
    }
};

export const login = async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }

        const { email, password } = req.body;

        // Find user with workspaces
        const user = await prisma.user.findUnique({
            where: { email },
            include: {
                workspaceMembers: {
                    include: {
                        workspace: true
                    },
                    orderBy: {
                        createdAt: 'asc'
                    },
                    take: 1
                }
            }
        });

        if (!user || !user.password) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        // Check password
        const isValidPassword = await bcrypt.compare(password, user.password);

        if (!isValidPassword) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        // Generate token
        const token = generateToken(user);

        // Get user's first workspace (their own workspace)
        const workspace = user.workspaceMembers[0]?.workspace;

        res.json({
            user: {
                id: user.id,
                email: user.email,
                name: user.name,
                role: user.role,
                avatar: user.avatar
            },
            workspace: workspace ? {
                id: workspace.id,
                name: workspace.name,
                slug: workspace.slug,
                members: [{
                    role: user.workspaceMembers[0].role
                }]
            } : null,
            token
        });
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ error: 'Login failed' });
    }
};

export const facebookCallback = async (req, res) => {
    try {
        const user = req.user;

        // Check if user has a workspace, if not create one
        const workspaceMember = await prisma.workspaceMember.findFirst({
            where: { userId: user.id },
            include: { workspace: true }
        });

        if (!workspaceMember) {
            // Create workspace for Facebook OAuth user
            await prisma.workspace.create({
                data: {
                    name: `${user.name}'s Workspace`,
                    slug: `${createSlug(user.name)}-${Date.now()}`,
                    description: 'My personal workspace',
                    members: {
                        create: {
                            userId: user.id,
                            role: 'OWNER'
                        }
                    }
                }
            });
        }

        const token = generateToken(user);

        // Redirect to frontend with token
        const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:5173';
        res.redirect(`${frontendUrl}/auth/callback?token=${token}`);
    } catch (error) {
        console.error('Facebook callback error:', error);
        res.redirect(`${process.env.FRONTEND_URL}/login?error=auth_failed`);
    }
};

export const getCurrentUser = async (req, res) => {
    try {
        const user = await prisma.user.findUnique({
            where: { id: req.user.id },
            select: {
                id: true,
                email: true,
                name: true,
                avatar: true,
                role: true,
                createdAt: true
            }
        });

        res.json({ user });
    } catch (error) {
        console.error('Get current user error:', error);
        res.status(500).json({ error: 'Failed to fetch user' });
    }
};
