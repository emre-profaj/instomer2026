import { validationResult } from 'express-validator';
import { PrismaClient } from '@prisma/client';
import axios from 'axios';

const prisma = new PrismaClient();
const GRAPH_API_VERSION = process.env.FACEBOOK_GRAPH_API_VERSION || 'v18.0';

export const connectPage = async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }

        const { pageId, pageAccessToken, pageName, workspaceId } = req.body;

        // Verify the page access token
        try {
            const response = await axios.get(
                `https://graph.facebook.com/${GRAPH_API_VERSION}/${pageId}`,
                {
                    params: {
                        fields: 'id,name',
                        access_token: pageAccessToken
                    }
                }
            );

            if (response.data.id !== pageId) {
                return res.status(400).json({ error: 'Invalid page credentials' });
            }
        } catch (error) {
            console.error('Facebook API verification error:', error.response?.data);
            return res.status(400).json({ error: 'Failed to verify Facebook page' });
        }

        // Check if page is already connected
        const existingPage = await prisma.facebookPage.findUnique({
            where: { pageId }
        });

        if (existingPage) {
            // Update the page
            const page = await prisma.facebookPage.update({
                where: { pageId },
                data: {
                    pageName,
                    pageAccessToken,
                    workspaceId
                }
            });
            return res.json({ page, message: 'Page updated successfully' });
        }

        // Create new page connection
        const page = await prisma.facebookPage.create({
            data: {
                pageId,
                pageName,
                pageAccessToken,
                workspaceId
            }
        });

        // Subscribe to webhooks
        try {
            await axios.post(
                `https://graph.facebook.com/${GRAPH_API_VERSION}/${pageId}/subscribed_apps`,
                {},
                {
                    params: {
                        subscribed_fields: 'messages,messaging_postbacks,messaging_optins',
                        access_token: pageAccessToken
                    }
                }
            );
        } catch (error) {
            console.error('Webhook subscription error:', error.response?.data);
            // Don't fail the request, just log the error
        }

        res.status(201).json({ page });
    } catch (error) {
        console.error('Connect page error:', error);
        res.status(500).json({ error: 'Failed to connect page' });
    }
};

export const getPages = async (req, res) => {
    try {
        const { workspaceId } = req.params;

        const pages = await prisma.facebookPage.findMany({
            where: { workspaceId },
            select: {
                id: true,
                pageId: true,
                pageName: true,
                createdAt: true,
                _count: {
                    select: {
                        conversations: true
                    }
                }
            }
        });

        res.json({ pages });
    } catch (error) {
        console.error('Get pages error:', error);
        res.status(500).json({ error: 'Failed to fetch pages' });
    }
};

export const disconnectPage = async (req, res) => {
    try {
        const { pageId } = req.params;

        const page = await prisma.facebookPage.findUnique({
            where: { id: pageId }
        });

        if (!page) {
            return res.status(404).json({ error: 'Page not found' });
        }

        await prisma.facebookPage.delete({
            where: { id: pageId }
        });

        res.json({ message: 'Page disconnected successfully' });
    } catch (error) {
        console.error('Disconnect page error:', error);
        res.status(500).json({ error: 'Failed to disconnect page' });
    }
};

// ADMIN ONLY: Get all pages from Facebook Developer account
export const getAdminFacebookPages = async (req, res) => {
    try {
        // Check if user is admin
        if (req.user.role !== 'ADMIN') {
            return res.status(403).json({ error: 'Admin access required' });
        }

        const adminAccessToken = process.env.FACEBOOK_ADMIN_ACCESS_TOKEN;

        if (!adminAccessToken) {
            return res.status(500).json({ error: 'Admin Facebook token not configured' });
        }

        // Get all pages managed by the admin token
        const response = await axios.get(
            `https://graph.facebook.com/${GRAPH_API_VERSION}/me/accounts`,
            {
                params: {
                    access_token: adminAccessToken,
                    fields: 'id,name,access_token,category,tasks'
                }
            }
        );

        const pages = response.data.data || [];

        // Check which pages are already connected
        const connectedPageIds = await prisma.facebookPage.findMany({
            select: { pageId: true }
        });

        const connectedIds = new Set(connectedPageIds.map(p => p.pageId));

        const pagesWithStatus = pages.map(page => ({
            id: page.id,
            name: page.name,
            category: page.category,
            accessToken: page.access_token,
            isConnected: connectedIds.has(page.id)
        }));

        res.json({ pages: pagesWithStatus });
    } catch (error) {
        console.error('Get admin Facebook pages error:', error.response?.data || error);
        res.status(500).json({ error: 'Failed to fetch Facebook pages' });
    }
};

// ADMIN ONLY: Connect a page from Facebook Developer account
export const connectAdminPage = async (req, res) => {
    try {
        // Check if user is admin
        if (req.user.role !== 'ADMIN') {
            return res.status(403).json({ error: 'Admin access required' });
        }

        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }

        const { pageId, pageAccessToken, pageName, workspaceId } = req.body;

        // Check if page is already connected
        const existingPage = await prisma.facebookPage.findUnique({
            where: { pageId }
        });

        if (existingPage) {
            // Update the page
            const page = await prisma.facebookPage.update({
                where: { pageId },
                data: {
                    pageName,
                    pageAccessToken,
                    workspaceId
                }
            });
            return res.json({ page, message: 'Page updated successfully' });
        }

        // Create new page connection
        const page = await prisma.facebookPage.create({
            data: {
                pageId,
                pageName,
                pageAccessToken,
                workspaceId
            }
        });

        // Subscribe to webhooks
        try {
            await axios.post(
                `https://graph.facebook.com/${GRAPH_API_VERSION}/${pageId}/subscribed_apps`,
                {},
                {
                    params: {
                        subscribed_fields: 'messages,messaging_postbacks,messaging_optins',
                        access_token: pageAccessToken
                    }
                }
            );
        } catch (error) {
            console.error('Webhook subscription error:', error.response?.data);
        }

        res.status(201).json({ page, message: 'Page connected successfully' });
    } catch (error) {
        console.error('Connect admin page error:', error);
        res.status(500).json({ error: 'Failed to connect page' });
    }
};

export const webhookVerify = (req, res) => {
    const VERIFY_TOKEN = process.env.FACEBOOK_VERIFY_TOKEN || 'chatinstomer_verify_token';

    const mode = req.query['hub.mode'];
    const token = req.query['hub.verify_token'];
    const challenge = req.query['hub.challenge'];

    if (mode && token) {
        if (mode === 'subscribe' && token === VERIFY_TOKEN) {
            console.log('Webhook verified');
            res.status(200).send(challenge);
        } else {
            res.sendStatus(403);
        }
    } else {
        res.sendStatus(400);
    }
};

export const webhookHandler = async (req, res) => {
    try {
        const body = req.body;

        if (body.object === 'page') {
            for (const entry of body.entry) {
                const webhookEvent = entry.messaging?.[0];

                if (!webhookEvent) continue;

                const senderId = webhookEvent.sender.id;
                const pageId = webhookEvent.recipient.id;
                const message = webhookEvent.message;

                // Find the Facebook page
                const facebookPage = await prisma.facebookPage.findUnique({
                    where: { pageId }
                });

                if (!facebookPage) {
                    console.log(`Page ${pageId} not found in database`);
                    continue;
                }

                // Find or create contact
                let contact = await prisma.contact.findUnique({
                    where: { facebookId: senderId }
                });

                if (!contact) {
                    // Fetch user info from Facebook
                    try {
                        const userInfo = await axios.get(
                            `https://graph.facebook.com/${GRAPH_API_VERSION}/${senderId}`,
                            {
                                params: {
                                    fields: 'name,profile_pic',
                                    access_token: facebookPage.pageAccessToken
                                }
                            }
                        );

                        contact = await prisma.contact.create({
                            data: {
                                facebookId: senderId,
                                name: userInfo.data.name,
                                avatar: userInfo.data.profile_pic
                            }
                        });
                    } catch (error) {
                        console.error('Error fetching user info:', error);
                        contact = await prisma.contact.create({
                            data: {
                                facebookId: senderId,
                                name: `User ${senderId}`
                            }
                        });
                    }
                }

                // Find or create conversation
                let conversation = await prisma.conversation.findFirst({
                    where: {
                        contactId: contact.id,
                        facebookPageId: facebookPage.id,
                        status: { not: 'RESOLVED' }
                    }
                });

                if (!conversation) {
                    conversation = await prisma.conversation.create({
                        data: {
                            contactId: contact.id,
                            workspaceId: facebookPage.workspaceId,
                            facebookPageId: facebookPage.id,
                            status: 'OPEN'
                        }
                    });
                }

                // Create message
                if (message?.text) {
                    await prisma.message.create({
                        data: {
                            content: message.text,
                            conversationId: conversation.id,
                            isFromContact: true,
                            facebookMessageId: message.mid,
                            messageType: 'TEXT'
                        }
                    });

                    // Update conversation last message time
                    await prisma.conversation.update({
                        where: { id: conversation.id },
                        data: { lastMessageAt: new Date() }
                    });
                }
            }

            res.status(200).send('EVENT_RECEIVED');
        } else {
            res.sendStatus(404);
        }
    } catch (error) {
        console.error('Webhook handler error:', error);
        res.sendStatus(500);
    }
};
