import express from 'express';
import { body } from 'express-validator';
import {
    getConversations,
    getConversation,
    sendMessage,
    assignConversation,
    updateConversationStatus
} from '../controllers/conversation.controller.js';
import { authenticateJWT, requireWorkspaceAccess } from '../middleware/auth.middleware.js';

const router = express.Router();

// All routes require authentication
router.use(authenticateJWT);

// Get conversations for workspace
router.get('/:workspaceId', requireWorkspaceAccess, getConversations);

// Get conversation details
router.get('/:workspaceId/:conversationId', requireWorkspaceAccess, getConversation);

// Send message
router.post(
    '/:workspaceId/:conversationId/messages',
    requireWorkspaceAccess,
    [
        body('content').notEmpty().withMessage('Message content is required')
    ],
    sendMessage
);

// Assign conversation
router.put(
    '/:workspaceId/:conversationId/assign',
    requireWorkspaceAccess,
    [
        body('assignedToId').notEmpty().withMessage('Agent ID is required')
    ],
    assignConversation
);

// Update conversation status
router.put(
    '/:workspaceId/:conversationId/status',
    requireWorkspaceAccess,
    [
        body('status').isIn(['OPEN', 'PENDING', 'RESOLVED']).withMessage('Valid status is required')
    ],
    updateConversationStatus
);

export default router;
