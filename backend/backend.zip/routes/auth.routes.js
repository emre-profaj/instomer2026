import express from 'express';
import passport from 'passport';
import { body } from 'express-validator';
import {
    register,
    login,
    facebookCallback,
    getCurrentUser
} from '../controllers/auth.controller.js';
import { authenticateJWT } from '../middleware/auth.middleware.js';

const router = express.Router();

// Register
router.post(
    '/register',
    [
        body('email').isEmail().withMessage('Valid email is required'),
        body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
        body('name').notEmpty().withMessage('Name is required')
    ],
    register
);

// Login
router.post(
    '/login',
    [
        body('email').isEmail().withMessage('Valid email is required'),
        body('password').notEmpty().withMessage('Password is required')
    ],
    login
);

// Facebook OAuth
router.get(
    '/facebook',
    passport.authenticate('facebook', {
        scope: ['email', 'pages_show_list', 'pages_messaging', 'pages_manage_metadata']
    })
);

router.get(
    '/facebook/callback',
    passport.authenticate('facebook', { session: false, failureRedirect: '/login' }),
    facebookCallback
);

// Get current user
router.get('/me', authenticateJWT, getCurrentUser);

export default router;
