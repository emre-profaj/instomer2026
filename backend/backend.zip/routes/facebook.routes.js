import express from 'express';
import { body } from 'express-validator';
import {
    connectPage,
    getPages,
    webhookVerify,
    webhookHandler,
    disconnectPage,
    getAdminFacebookPages,
    connectAdminPage
} from '../controllers/facebook.controller.js';
import { authenticateJWT, requireWorkspaceAccess, requireRole } from '../middleware/auth.middleware.js';

const router = express.Router();

// Webhook verification (GET) - no auth required
router.get('/webhook', webhookVerify);

// Webhook handler (POST) - no auth required
router.post('/webhook', webhookHandler);

// All other routes require authentication
router.use(authenticateJWT);

// ADMIN ONLY: Get all pages from Facebook Developer account
router.get('/admin/pages', requireRole('ADMIN'), getAdminFacebookPages);

// ADMIN ONLY: Connect a page from Facebook Developer account
router.post(
    '/admin/connect-page',
    requireRole('ADMIN'),
    [
        body('pageId').notEmpty().withMessage('Page ID is required'),
        body('pageAccessToken').notEmpty().withMessage('Page access token is required'),
        body('pageName').notEmpty().withMessage('Page name is required'),
        body('workspaceId').notEmpty().withMessage('Workspace ID is required')
    ],
    connectAdminPage
);

// Connect Facebook page (regular users)
router.post(
    '/pages/connect',
    [
        body('pageId').notEmpty().withMessage('Page ID is required'),
        body('pageAccessToken').notEmpty().withMessage('Page access token is required'),
        body('pageName').notEmpty().withMessage('Page name is required'),
        body('workspaceId').notEmpty().withMessage('Workspace ID is required')
    ],
    requireWorkspaceAccess,
    connectPage
);

// Get connected pages for workspace
router.get('/pages/:workspaceId', requireWorkspaceAccess, getPages);

// Disconnect page
router.delete('/pages/:pageId', disconnectPage);

export default router;
