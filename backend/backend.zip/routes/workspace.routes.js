import express from 'express';
import { body } from 'express-validator';
import {
    createWorkspace,
    getWorkspaces,
    getWorkspace,
    addMember,
    updateMemberRole,
    removeMember,
    getWorkspaceMembers
} from '../controllers/workspace.controller.js';
import { authenticateJWT, requireWorkspaceAccess } from '../middleware/auth.middleware.js';

const router = express.Router();

// All routes require authentication
router.use(authenticateJWT);

// Create workspace
router.post(
    '/',
    [
        body('name').notEmpty().withMessage('Workspace name is required'),
        body('slug').notEmpty().withMessage('Workspace slug is required')
    ],
    createWorkspace
);

// Get user's workspaces
router.get('/', getWorkspaces);

// Get workspace details
router.get('/:workspaceId', requireWorkspaceAccess, getWorkspace);

// Get workspace members
router.get('/:workspaceId/members', requireWorkspaceAccess, getWorkspaceMembers);

// Add member to workspace
router.post(
    '/:workspaceId/members',
    requireWorkspaceAccess,
    [
        body('email').isEmail().withMessage('Valid email is required'),
        body('role').isIn(['OWNER', 'ADMIN', 'AGENT']).withMessage('Valid role is required')
    ],
    addMember
);

// Update member role
router.put(
    '/:workspaceId/members/:userId',
    requireWorkspaceAccess,
    [
        body('role').isIn(['OWNER', 'ADMIN', 'AGENT']).withMessage('Valid role is required')
    ],
    updateMemberRole
);

// Remove member
router.delete('/:workspaceId/members/:userId', requireWorkspaceAccess, removeMember);

export default router;
